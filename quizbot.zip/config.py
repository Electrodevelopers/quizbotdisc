ch_name = 'викторина-бот'
token = 'NjgwODQwNDczOTc1NTg2OTkz.XlFz-A.aDtEKtDhI0X2vssCKz7q5VNIC8w'
ch_id = '680844287478726668'
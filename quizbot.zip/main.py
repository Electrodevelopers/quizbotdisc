import discord,asyncio,config,questions,random
client = discord.Client()
global game
game = False
global games
games = False
global users
users = []
global ans 
ans = ''
global uans
uans = []
def stg():
	global game
	game = True
async def waitans(ch):
	global users
	if(len(users) != 1):
		await asyncio.sleep(10)
		for i in users:
			global uans
			if(i not in uans):
				await ch.send('{0} выбывает из игры!'.format(client.get_user(i).name))
				users.remove(i)
			if(i in uans):
				await ch.send('{0} дает правильный ответ!'.format(client.get_user(i).name))
		await sendquestion(ch)
	else:
		await ch.send('{0} выиграл игру!'.format(client.get_user(users[0])))
async def sendquestion(ch):
	global ans 
	quen = random.randint(0,len(questions.que)-1)
	await ch.send(questions.que[quen][0] + '\n У вас есть 10 секунд!')
	ans = questions.que[quen][1]
	await waitans(ch)
async def startquiz(ch):
	await asyncio.sleep(30)
	global users
	global games
	print(int(len(users)))
	if(len(users) == 1 or len(users) == 0):
		users = []
		global game
		game = False
		games = False
		global ans
		ans = ''
		global uans
		uans = []
		await ch.send('Для игры нужно более двух человек')
	else:
		await ch.send('Викторина начинается!')
		games = True
		await sendquestion(ch)
@client.event
async def on_ready():
	print('Bot is ready')

@client.event
async def on_message(msg):
	roles = []
	if(str(msg.channel) == 'викторина-бот'):
		for i in msg.author.roles: #Get roles of author
			roles.append(str(i.name))
		global game
		global games
		global ans
		global users
		if('мастер викторины' in roles):  #If author is administratorcmd
			if(str(msg.content) == 'Qstart' and game == False and games == False):
				ch = msg.channel
				await ch.send('Викторина начнется через 30 секунд. Подключайтесь через команду "Qjoin"')
				stg()
				await startquiz(msg.channel)
		if(str(msg.content) == 'Qjoin' and game == True and msg.author.id not in users and games == False):
			await msg.channel.send('{0} присоединяется к игре!'.format(msg.author.name))
			users.append(msg.author.id)
			print(users)
		if(games==True and game == True and msg.author.id in users and str(msg.content) == ans):
			uans.append(msg.author.id)

client.run('NjgwODQwNDczOTc1NTg2OTkz.XlF3Gw.xK7URob87SFm06nADkZ029XNRCo')